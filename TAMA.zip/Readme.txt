#How to run the code

1. Download the dateset used ‘creditcard.csv’ from this link: https://www.kaggle.com/mlg-ulb/creditcardfraud/download

Alternatively, the dataset can be downloaded from the following link: https://drive.google.com/file/d/1hccdptHw1-K1F4-gtmqIZfmRb85TTgUV/view?usp=sharing


2. Install the required packages.

3. Uoload the Python notebook in any IDE capable of running python notebook, preferably, Google Colab.

